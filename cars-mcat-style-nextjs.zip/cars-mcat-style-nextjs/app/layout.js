import "./globals.css";
export const metadata = { title: "CARS Mastery" };
export default function RootLayout({ children }) { return <html lang="en"><body>{children}</body></html>; }
