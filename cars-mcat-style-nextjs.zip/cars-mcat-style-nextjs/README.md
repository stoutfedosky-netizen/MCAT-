# MCAT-Style CARS Practice Portal

Run:

```bash
npm install
npm run dev
```

Open http://localhost:3000

Features: split screen, blue MCAT-style interface, timer, highlighting, strikethrough, flagging, navigation, explanations.
